/*
 Program: Priority round robin algorithm with quantum of 10
 Author: Abdirahman Hassan
 Date: 5/13/2021

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "task.h"
#include "list.h"
#include "schedulers.h"
#include "cpu.h"

#define QUANTUM 10

struct node *head; // first task
struct node *tail; // last task
struct node *newTask; // new task
struct node *rrHead; // list of tasks that are similar by burst
int numberOfTask=0; //total number of task



//check if the two task are equal
// if the same name they are equal, else not
bool isEqual(char *a, char *b) 
{ 
    return strcmp(a, b) ==0; 
}

// delete task from the list
void removeTask(struct node **rHead, Task *task)
{
    struct node *temp = *rHead, *prev;
 
    // If head node itself holds the key to be deleted
    if (temp != NULL && task!=NULL && isEqual(task->name,temp->task->name)) {
        *rHead = temp->next; // Changed head
        free(temp); // free old head
        numberOfTask--;
        return;
    }
 
    // Search for the task to be deleted, keep track of the
    // previous task as we need to change 'prev->next'
    while (temp != NULL && !isEqual(task->name,temp->task->name)) {
        prev = temp;
        temp = temp->next;
    }
 
    // If task  was not present in list
    if (temp == NULL)
        return;
 
    // Unlink the task from linked list
    if(temp->next==NULL)
    {
        prev->next = temp->next;
        tail=prev->next;
    }
    else prev->next = temp->next;
 
    free(temp); // Free memory
    numberOfTask--;
}
//check if task a comes before task b 
bool comesAfter(char *a, char *b) 
{ 
    return strcmp(a, b) > 0; 
}

// checks if task 1 priority is greater than task 2 priority  
bool isGreater(int t1,int t2)
{
    return t1>t2;  
}

//check if the two task are equal
// if the same name they are equal, else not
bool isPriorityEqaul(int t1, int t2) 
{ 
    return t1==t2; 
}

// insert the new task from the from the begining
void insertFromTheBegining( struct node *newT)
{
    struct node *current=malloc(sizeof(struct node));
    current=NULL;
    struct node *traversal=head;
    while(traversal)
    {
       if(isGreater(traversal->task->priority, newT->task->priority)) // if prio
       {
          current=traversal;
          traversal=traversal->next;

       }
       else if(isPriorityEqaul(newT->task->priority,traversal->task->priority) && comesAfter(newT->task->name,traversal->task->name))  // if they are same 
                                                                                                                             // check if newt comes after traversal task
       {
           current=traversal;
           traversal=traversal->next;
       }
       else break;

    }
    if(!traversal)// at end of the list
    {
        current->next=newT;
        newT->next=NULL;
        tail=newT;
        numberOfTask++;
    }
    else{ // either at the back or middle
        if(!current) // insert at the front
        {
            newT->next=head;
            head=newT;
            numberOfTask++;
            return;


        }
        //somewhere in the middle
        newT->next=traversal;
        current->next=newT;
        numberOfTask++;
    }
}

// add a task to be processed 
void add(char *name, int priority, int burst)
{
    if(!head) // first task
    {
        head=malloc(sizeof(struct node));
        tail=malloc(sizeof(struct node));

        head->task= malloc(sizeof(struct task));
        head->task->name=name;
        head->task->burst=burst;
        head->task->priority=priority;
        head->next=NULL;
        tail=head;
        numberOfTask++;

    }
    else{ //else add new task accordingly
       newTask=malloc(sizeof(struct node));
       newTask->task=malloc(sizeof(struct task));
       newTask->task->priority=priority;
       newTask->task->burst=burst;
       newTask->task->name=name;
       insertFromTheBegining(newTask); // inserts from the begining

    }
}
// invoke the scheduler
void schedule(){

    struct node *current=head; // process the task with the highest priority
    while(numberOfTask>0) // will run till all the tasks are finished
    {
        if(current->next && !isPriorityEqaul(current->task->priority,current->next->task->priority)) // if no task with same prioriry let it run
        {
            run(current->task,current->task->burst);
            Task *toRemove=current->task;
            
            removeTask(&head,toRemove); //from the list 
            if(head) current=head;
            else current=NULL;

        }
        else{ // head next tasks have the same priority 
            int priority_to_rr=current->task->priority; // keep track of the priority we need to process
            while(current  && head && head->task->priority==priority_to_rr){ // while head is not changed 
                if(current->task->burst>QUANTUM) // run burst - quatum 
                {
                    
                    run(current->task,QUANTUM);
                    current->task->burst-=QUANTUM;
                    if(current->next && isPriorityEqaul(current->task->priority,current->next->task->priority)) current=current->next; // check if next has the same priority
                    else // go back to head
                    {
                        if(head) current=head;
                        else current=NULL;
                    }
                }
                else{ //run the remaning burst time
                    run(current->task,current->task->burst);
                    int currentPriority= current->task->priority; 
                    Task *toRemove=current->task;
                    removeTask(&head,toRemove);
                    if(current->next && isPriorityEqaul(currentPriority,current->next->task->priority))current=current->next;
                    else
                    {
                        if(head) current=head;
                        else current=NULL;
                    }
                  }  
                }
            }
    }
    printf("Done !\n");
}