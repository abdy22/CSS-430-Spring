/*
 Program: Round robin algorithm with quantum of 10
 Author: Abdirahman Hassan
 Date: 5/13/2021

*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "task.h"
#include "list.h"
#include "schedulers.h"
#include "cpu.h"

#define QUANTUM 10 

struct node *head; // first task
struct node *tail; // last task
struct node *newTask; // new task

int numberOfTask=0; //total number of tasks

//check if the two task are equal
// if the same name they are equal, else not
bool isEqual(char *a, char *b) { return strcmp(a, b) == 0; }

// delete task from the list
void removeTask(struct node **rHead, Task *task)
{
    struct node *temp = *rHead, *prev;
 
    // If head task itself holds the key to be deleted
    if (temp != NULL && task!=NULL && isEqual(task->name,temp->task->name)) {
        *rHead = temp->next; // Changed head
        free(temp); // free old head
        numberOfTask--;
        return;
    }
 
    // Search for the task to be deleted, keep track of the
    // previous task as we need to change 'prev->next'
    while (temp != NULL && !isEqual(task->name,temp->task->name)) {
        prev = temp;
        temp = temp->next;
    }
 
    // If task was not present in linked list
    if (temp == NULL)
        return;
 
    // Unlink the task from linked list
    if(temp->next==NULL)
    {
        prev->next = temp->next;
        tail=prev->next;
    }
    else prev->next = temp->next;
 
    free(temp); // Free memory
    numberOfTask--;
}

// add a task to the list 
void add(char *name, int priority, int burst){
    if(!head) // first task
    {
        head=malloc(sizeof(struct node));
        tail=malloc(sizeof(struct node));

        head->task= malloc(sizeof(struct task));
        head->task->name=name;
        head->task->burst=burst;
        head->task->priority=priority;
        head->next=NULL;
        tail=head;
        numberOfTask++;

    }
    else
    { //new task
       newTask=malloc(sizeof(struct node));
       tail->next=newTask;
       newTask->task=malloc(sizeof(struct task));
       newTask->task->priority=priority;
       newTask->task->burst=burst;
       newTask->task->name=name;
       newTask->next=NULL;
       tail=newTask;
       numberOfTask++;
    }

}

// invoke the scheduler
void schedule(){

    struct node *current=head;
    while(numberOfTask>0) // run while there task to be processed 
    {
        while(current)// run through the end of the list
        {
            if(current->task->burst>QUANTUM)
            {
                run(current->task,QUANTUM);
                current->task->burst-=QUANTUM;
                current=current->next;
            }
            else{
                run(current->task,current->task->burst);
                struct node *toRemove=current;
                
                removeTask(&head,toRemove->task);
                current=current->next;
                
            }  
        }
        current=head; // goes back to head
        


    }
    printf("Done !\n");
}


