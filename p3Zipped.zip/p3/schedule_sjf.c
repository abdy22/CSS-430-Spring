/*
 Program: SJF algorithm to process tasks that have shortest burst time
 Author: Abdirahman Hassan
 Date: 5/13/2021

*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "task.h"
#include "list.h"
#include "schedulers.h"
#include "cpu.h"

struct node *head; // first task
struct node *tail; // last task
struct node *newTask; // new task

// checks if task 1 burst time is less than task 2 burst time 
// if burst time equal, 
bool isLess(int t1,int t2)
{
    return t1<t2;  
}
//check if the two task are equal
// if the same name they are equal, else not
bool comesAfter(char *a, char *b) { return strcmp(a, b) < 0; }

// checks if task 1 burst is greater than task 2 burst  
bool isGreater(int t1,int t2)
{
    return t1>t2;  
}

//check if the two task are equal
// if the same name they are equal, else not
bool isEqual(int t1, int t2) { return t1== t2; }

// insert the new task from the from the begining
void insertFronBegining( struct node *newT)
{
    

    struct node *current=malloc(sizeof(struct node));
    current=NULL;
    struct node *traversal=head;
    while(traversal) // traversal is not NULL
    {
       if(isGreater(newT->task->burst,traversal->task->burst)) // if the new task has bigger burst then go to the next in the list
       {
          current=traversal;
          traversal=traversal->next;

       }
       else if(isEqual(newT->task->burst,traversal->task->burst) && comesAfter(traversal->task->name,newT->task->name)) // if they are same 
                                                                                                                             // check if newt comes after traversal task
       {
           current=traversal;
           traversal=traversal->next;
       }
       

       else break; //found a place to insert

    }
    if(!traversal)// at end of the list
    {
        current->next=newT;
        newT->next=NULL;
        tail=newT;
    }
    else{ // either begining or in the middle
        if(!current)
        { // begining
            newT->next=head;
            head=newT;
            return;


        } 
        // middle 
        newT->next=traversal;
        current->next=newT;

    }
  
}

// add a task to the list 
void add(char *name, int priority, int burst)
{
    if(!head) // first task
    {
        head=malloc(sizeof(struct node));
        tail=malloc(sizeof(struct node));

        head->task= malloc(sizeof(struct task));
        head->task->name=name;
        head->task->burst=burst;
        head->task->priority=priority;
        head->next=NULL;
        tail=head;

    }
    else{ //else add new task accordingly
       newTask=malloc(sizeof(struct node));
       newTask->task=malloc(sizeof(struct task));
       newTask->task->priority=priority;
       newTask->task->burst=burst;
       newTask->task->name=name;
       insertFronBegining(newTask); // inserts from the begining 

    }
}
// invoke the scheduler
void schedule()
{

    struct node *current=head;
    while(current) // not at the end of the task list
    {
         run(current->task,current->task->burst);
         current=current->next;


    }
    printf("Done !\n");
}