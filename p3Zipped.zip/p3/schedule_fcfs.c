/*
 Program: FCFS algorithm to process task in the order they came. 
 Author: Abdirahman Hassan
 Date: 5/13/2021

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "task.h"
#include "list.h"
#include "schedulers.h"
#include "cpu.h"

struct node *head; // first task
struct node *tail; // last task
struct node *newTask; // new task
int numberOfTask=0; //total number of task 

// add a task to the list 
void add(char *name, int priority, int burst){
    if(!head) // first task
    {
        head=malloc(sizeof(struct node));
        tail=malloc(sizeof(struct node));

        head->task= malloc(sizeof(struct task));
        head->task->name=name;
        head->task->burst=burst;
        head->task->priority=priority;
        head->next=NULL;
        tail=head;
        numberOfTask++;

    }
    else
    { //new task add to the back
       newTask=malloc(sizeof(struct node));
       tail->next=newTask;
       newTask->task=malloc(sizeof(struct task));
       newTask->task->priority=priority;
       newTask->task->burst=burst;
       newTask->task->name=name;
       newTask->next=NULL;
       tail=newTask;
       numberOfTask++; //increment the number of task
    }
}

// invoke the scheduler
void schedule(){

    struct node *current=head;
    while(current) // end to the list
    {
         run(current->task,current->task->burst);
         current=current->next;


    }
    printf("Done !\n");
}
