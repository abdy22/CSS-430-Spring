 gcc SudokuVDT.c  -o validator -pthread
 